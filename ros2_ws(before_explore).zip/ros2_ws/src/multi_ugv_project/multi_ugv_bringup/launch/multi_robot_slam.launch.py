#!/usr/bin/env python3

import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, DeclareLaunchArgument, ExecuteProcess, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

def generate_launch_description():
    # 패키지 경로
    pkg_bringup = get_package_share_directory('multi_ugv_bringup')
    pkg_config = get_package_share_directory('multi_ugv_config')
    
    # Cartographer 설정 파일 경로 확인
    cartographer_config_dir = os.path.join(pkg_config, 'params')
    
    # 정확한 월드 파일 경로 지정
    source_world_path = os.path.join(pkg_bringup, 'worlds', 'maze.world')
    
    # 디버그 정보 출력
    print(f"월드 파일 확인: {source_world_path}")
    if os.path.exists(source_world_path):
        print(f"✅ 월드 파일 발견")
        world_path = source_world_path
    else:
        print(f"❌ 월드 파일 없음")
        world_path = os.path.join(get_package_share_directory('gazebo_ros'), 'worlds', 'empty.world')
    
    # Cartographer 설정 파일 확인
    robot1_config = os.path.join(cartographer_config_dir, 'cartographer_robot1.lua')
    robot2_config = os.path.join(cartographer_config_dir, 'cartographer_robot2.lua')
    robot3_config = os.path.join(cartographer_config_dir, 'cartographer_robot3.lua')
    
    print(f"Cartographer 설정 파일 확인:")
    print(f"Robot1: {robot1_config} - {'✅ 발견' if os.path.exists(robot1_config) else '❌ 없음'}")
    print(f"Robot2: {robot2_config} - {'✅ 발견' if os.path.exists(robot2_config) else '❌ 없음'}")
    print(f"Robot3: {robot3_config} - {'✅ 발견' if os.path.exists(robot3_config) else '❌ 없음'}")
    
    # 런치 파라미터
    use_sim_time = LaunchConfiguration('use_sim_time', default='true')
    
    # 가제보 실행
    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(get_package_share_directory('gazebo_ros'), 'launch', 'gazebo.launch.py')
        ),
        launch_arguments={
            'world': world_path,
            'verbose': 'true'
        }.items()
    )
    
    # 맵 컨버터 노드 (지연 시작)
    map_converter_node = TimerAction(
        period=3.0,
        actions=[
            Node(
                package='multi_ugv_control',
                executable='map_converter',
                name='map_converter',
                parameters=[{'use_sim_time': use_sim_time}],
                output='screen'
            )
        ]
    )
    
    # TF 매니저 노드 (새로 추가)
    tf_manager_node = TimerAction(
        period=5.0,
        actions=[
            Node(
                package='multi_ugv_control',
                executable='tf_manager',
                name='tf_manager',
                parameters=[{'use_sim_time': use_sim_time}],
                output='screen'
            )
        ]
    )
    
    # 기본 로봇 스폰 런치 파일 (가제보 실행 후 지연)
    multi_robot_launch = TimerAction(
        period=8.0,
        actions=[
            IncludeLaunchDescription(
                PythonLaunchDescriptionSource(
                    os.path.join(pkg_bringup, 'launch', 'multi_robot.launch.py')
                )
            )
        ]
    )
    
    # SLAM 노드들 (로봇 스폰 후 지연)
    slam_nodes = TimerAction(
        period=20.0,
        actions=[
            # 로봇1 SLAM 노드
            Node(
                package='multi_ugv_control',
                executable='slam_node',
                name='robot1_slam',
                namespace='robot1',
                parameters=[{'use_sim_time': use_sim_time}],
                arguments=['robot1'],
                output='screen'
            ),
            
            # 로봇2 SLAM 노드
            Node(
                package='multi_ugv_control',
                executable='slam_node',
                name='robot2_slam',
                namespace='robot2',
                parameters=[{'use_sim_time': use_sim_time}],
                arguments=['robot2'],
                output='screen'
            ),
            
            # 로봇3 SLAM 노드
            Node(
                package='multi_ugv_control',
                executable='slam_node',
                name='robot3_slam',
                namespace='robot3',
                parameters=[{'use_sim_time': use_sim_time}],
                arguments=['robot3'],
                output='screen'
            ),
            
            # 로봇1 Cartographer 노드
            Node(
                package='cartographer_ros',
                executable='cartographer_node',
                name='robot1_cartographer',
                namespace='robot1',
                parameters=[{'use_sim_time': use_sim_time}],
                arguments=[
                    '-configuration_directory', cartographer_config_dir,
                    '-configuration_basename', 'cartographer_robot1.lua'
                ],
                remappings=[
                    ('scan', '/robot1/scan'),
                    ('imu', '/robot1/imu/data'),
                    ('odom', '/robot1/odom'),
                    ('map', '/robot1/map')
                ],
                output='screen'
            ),

            # 로봇1 Occupancy Grid 노드
            Node(
                package='cartographer_ros',
                executable='cartographer_occupancy_grid_node',
                name='robot1_occupancy_grid_node',
                namespace='robot1',
                parameters=[{'use_sim_time': use_sim_time}],
                arguments=[
                    '-resolution', '0.05',
                    '-publish_period_sec', '1.0'
                ],
                remappings=[
                    ('map', '/robot1/map')
                ],                
                output='screen'
            ),

            # 로봇2 Cartographer 노드
            Node(
                package='cartographer_ros',
                executable='cartographer_node',
                name='robot2_cartographer',
                namespace='robot2',
                parameters=[{'use_sim_time': use_sim_time}],
                arguments=[
                    '-configuration_directory', cartographer_config_dir,
                    '-configuration_basename', 'cartographer_robot2.lua'
                ],
                remappings=[
                    ('scan', '/robot2/scan'),
                    ('imu', '/robot2/imu/data'),
                    ('odom', '/robot2/odom')
                ],
                output='screen'
            ),

            # 로봇2 Occupancy Grid 노드
            Node(
                package='cartographer_ros',
                executable='cartographer_occupancy_grid_node',
                name='robot2_occupancy_grid_node',
                namespace='robot2',
                parameters=[{'use_sim_time': use_sim_time}],
                arguments=[
                    '-resolution', '0.05',
                    '-publish_period_sec', '1.0'
                ],
                output='screen'
            ),

            # 로봇3 Cartographer 노드
            Node(
                package='cartographer_ros',
                executable='cartographer_node',
                name='robot3_cartographer',
                namespace='robot3',
                parameters=[{'use_sim_time': use_sim_time}],
                arguments=[
                    '-configuration_directory', cartographer_config_dir,
                    '-configuration_basename', 'cartographer_robot3.lua'
                ],
                remappings=[
                    ('scan', '/robot3/scan'),
                    ('imu', '/robot3/imu/data'),
                    ('odom', '/robot3/odom')
                ],
                output='screen'
            ),

            # 로봇3 Occupancy Grid 노드
            Node(
                package='cartographer_ros',
                executable='cartographer_occupancy_grid_node',
                name='robot3_occupancy_grid_node',
                namespace='robot3',
                parameters=[{'use_sim_time': use_sim_time}],
                arguments=[
                    '-resolution', '0.05',
                    '-publish_period_sec', '1.0'
                ],
                output='screen'
            ),
            
            # 조인트 스테이트 노드들
            Node(
                package='multi_ugv_control',
                executable='joint_state_publisher',
                name='robot1_joint_state_publisher',
                namespace='robot1',
                parameters=[{'use_sim_time': use_sim_time}],
                arguments=['robot1'],
                output='screen'
            ),
            
           Node(
                package='multi_ugv_control',
                executable='joint_state_publisher',
                name='robot2_joint_state_publisher',
                namespace='robot2',
                parameters=[{'use_sim_time': use_sim_time}],
                arguments=['robot2'],
                output='screen'
            ),
            
            Node(
                package='multi_ugv_control',
                executable='joint_state_publisher',
                name='robot3_joint_state_publisher',
                namespace='robot3',
                parameters=[{'use_sim_time': use_sim_time}],
                arguments=['robot3'],
                output='screen'
            )
        ]
    )
    # Nav2 노드들 (SLAM 노드 실행 후 지연)
    nav2_nodes = TimerAction(
        period=25.0,  # SLAM 노드 실행 후 5초 더 기다림
        actions=[
            # 로봇1 Nav2 노드들
            Node(
                package='nav2_lifecycle_manager',
                executable='lifecycle_manager',
                name='lifecycle_manager_navigation',
                namespace='robot1',
                output='screen',
                parameters=[
                    {'use_sim_time': use_sim_time},
                    {'autostart': True},
                    {'node_names': [
                        'controller_server',
                        'planner_server',
                        'bt_navigator',
                        'waypoint_follower'
                    ]}
                ]
            ),
        
            Node(
                package='nav2_planner',
                executable='planner_server',
                name='planner_server',
                namespace='robot1',
                output='screen',
                parameters=[os.path.join(cartographer_config_dir, 'robot1_nav2_params.yaml')]
            ),
        
            Node(
                package='nav2_controller',
                executable='controller_server',
                name='controller_server',
                namespace='robot1',
                output='screen',
                parameters=[os.path.join(cartographer_config_dir, 'robot1_nav2_params.yaml')]
            ),
            Node(
                package='nav2_behaviors',  # recoveries를 behaviors로 변경
                executable='behavior_server',  # recoveries_server를 behavior_server로 변경
                name='behavior_server',  # 노드 이름도 변경
                namespace='robot1',
                output='screen',
                parameters=[os.path.join(cartographer_config_dir, 'robot1_nav2_params.yaml'), {'use_sim_time': use_sim_time}]
            ),
            
            Node(
                package='nav2_bt_navigator',
                executable='bt_navigator',
                name='bt_navigator',
                namespace='robot1',
                output='screen',
                parameters=[os.path.join(cartographer_config_dir, 'robot1_nav2_params.yaml')]
            ),
            
            Node(
                package='nav2_waypoint_follower',
                executable='waypoint_follower',
                name='waypoint_follower',
                namespace='robot1',
                output='screen',
                parameters=[os.path.join(cartographer_config_dir, 'robot1_nav2_params.yaml')]
            ),
        
            # 로봇2 Nav2 노드들
            Node(
                package='nav2_lifecycle_manager',
                executable='lifecycle_manager',
                name='lifecycle_manager_navigation',
                namespace='robot2',
                output='screen',
                parameters=[
                    {'use_sim_time': use_sim_time},
                    {'autostart': True},
                    {'node_names': [
                        'controller_server',
                        'planner_server',
                        'bt_navigator',
                        'waypoint_follower'
                    ]}
                ]
            ),
            
            Node(
                package='nav2_planner',
                executable='planner_server',
                name='planner_server',
                namespace='robot2',
                output='screen',
                parameters=[os.path.join(cartographer_config_dir, 'robot2_nav2_params.yaml')]
            ),
            Node(
                package='nav2_behaviors',  # recoveries를 behaviors로 변경
                executable='behavior_server',  # recoveries_server를 behavior_server로 변경
                name='behavior_server',  # 노드 이름도 변경
                namespace='robot2',
                output='screen',
                parameters=[os.path.join(cartographer_config_dir, 'robot2_nav2_params.yaml'), {'use_sim_time': use_sim_time}]
            ),            
            Node(
                package='nav2_controller',
                executable='controller_server',
                name='controller_server',
                namespace='robot2',
                output='screen',
                parameters=[os.path.join(cartographer_config_dir, 'robot2_nav2_params.yaml')]
            ),
            
            
            Node(
                package='nav2_bt_navigator',
                executable='bt_navigator',
                name='bt_navigator',
                namespace='robot2',
                output='screen',
                parameters=[os.path.join(cartographer_config_dir, 'robot2_nav2_params.yaml')]
            ),
            
            Node(
                package='nav2_waypoint_follower',
                executable='waypoint_follower',
                name='waypoint_follower',
                namespace='robot2',
                output='screen',
                parameters=[os.path.join(cartographer_config_dir, 'robot2_nav2_params.yaml')]
            ),
            
            # 로봇3 Nav2 노드들
            Node(
                package='nav2_lifecycle_manager',
                executable='lifecycle_manager',
                name='lifecycle_manager_navigation',
                namespace='robot3',
                output='screen',
                parameters=[
                    {'use_sim_time': use_sim_time},
                    {'autostart': True},
                    {'node_names': [
                        'controller_server',
                        'planner_server',
                        'bt_navigator',
                        'waypoint_follower'
                    ]}
                ]
            ),
        
            Node(
                package='nav2_planner',
                executable='planner_server',
                name='planner_server',
                namespace='robot3',
                output='screen',
                parameters=[os.path.join(cartographer_config_dir, 'robot3_nav2_params.yaml')]
            ),
        
            Node(
                package='nav2_controller',
                executable='controller_server',
                name='controller_server',
                namespace='robot3',
                output='screen',
                parameters=[os.path.join(cartographer_config_dir, 'robot3_nav2_params.yaml')]
            ),
            Node(
                package='nav2_behaviors',  # recoveries를 behaviors로 변경
                executable='behavior_server',  # recoveries_server를 behavior_server로 변경
                name='behavior_server',  # 노드 이름도 변경
                namespace='robot3',
                output='screen',
                parameters=[os.path.join(cartographer_config_dir, 'robot3_nav2_params.yaml'), {'use_sim_time': use_sim_time}]
            ),        
            Node(
                package='nav2_bt_navigator',
                executable='bt_navigator',
                name='bt_navigator',
                namespace='robot3',
                output='screen',
                parameters=[os.path.join(cartographer_config_dir, 'robot3_nav2_params.yaml')]
            ),
        
            Node(
                package='nav2_waypoint_follower',
                executable='waypoint_follower',
                name='waypoint_follower',
                namespace='robot3',
                output='screen',
                parameters=[os.path.join(cartographer_config_dir, 'robot3_nav2_params.yaml')]
            )
        ]
    )    
    # RViz 노드들 (마지막 실행)
    rviz_nodes = TimerAction(
        period=25.0,  # SLAM 노드 시작 후 5초 더 지연
        actions=[
            # 로봇1의 RViz - Fixed Frame을 robot1/map으로 설정
            Node(
                package='rviz2',
                executable='rviz2',
                name='robot1_rviz',
                namespace='robot1',
                arguments=['-d', os.path.join(pkg_bringup, 'config', 'robot1.rviz')],
                parameters=[{'use_sim_time': use_sim_time}],
                output='screen'
            ),
            
            # 로봇2의 RViz - Fixed Frame을 robot2/map으로 설정
            Node(
                package='rviz2',
                executable='rviz2',
                name='robot2_rviz',
                namespace='robot2',
                arguments=['-d', os.path.join(pkg_bringup, 'config', 'robot2.rviz')],
                parameters=[{'use_sim_time': use_sim_time}],
                output='screen'
            ),
            
            # 로봇3의 RViz - Fixed Frame을 robot3/map으로 설정
            Node(
                package='rviz2',
                executable='rviz2',
                name='robot3_rviz',
                namespace='robot3',
                arguments=['-d', os.path.join(pkg_bringup, 'config', 'robot3.rviz')],
                parameters=[{'use_sim_time': use_sim_time}],
                output='screen'
            )
        ]
    )
    
    # LaunchDescription 반환
    return LaunchDescription([
        # 런치 파라미터
        DeclareLaunchArgument(
            'use_sim_time',
            default_value='true',
            description='시뮬레이션 시간 사용 여부'
        ),
        
        # 가제보 실행
        gazebo,
        
        # 순차적으로 실행
        map_converter_node,  # 맵 컨버터 노드 활성화
        tf_manager_node,
        multi_robot_launch,
        slam_nodes,
        nav2_nodes,
        rviz_nodes
    ])
