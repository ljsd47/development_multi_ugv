#!/usr/bin/env python3

import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, DeclareLaunchArgument, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

def generate_launch_description():
    # 패키지 경로
    pkg_bringup = get_package_share_directory('multi_ugv_bringup')
    
    # 사용할 파라미터
    use_sim_time = LaunchConfiguration('use_sim_time', default='true')
    
    # SLAM 런치 파일 포함
    multi_robot_slam_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_bringup, 'launch', 'multi_robot_slam.launch.py')
        )
    )
    
    # 좌표 송수신 노드 (SLAM이 준비된 후)
    coord_nodes = TimerAction(
        period=20.0,
        actions=[
            # 로봇1 좌표 송수신 노드
            Node(
                package='multi_ugv_control',
                executable='coord_transmission',
                name='robot1_coord',
                namespace='robot1',
                parameters=[{'use_sim_time': use_sim_time}],
                arguments=['robot1'],
                output='screen'
            ),
            
            # 로봇2 좌표 송수신 노드
            Node(
                package='multi_ugv_control',
                executable='coord_transmission',
                name='robot2_coord',
                namespace='robot2',
                parameters=[{'use_sim_time': use_sim_time}],
                arguments=['robot2'],
                output='screen'
            ),
            
            # 로봇3 좌표 송수신 노드
            Node(
                package='multi_ugv_control',
                executable='coord_transmission',
                name='robot3_coord',
                namespace='robot3',
                parameters=[{'use_sim_time': use_sim_time}],
                arguments=['robot3'],
                output='screen'
            )
        ]
    )
    
    # LaunchDescription 반환
    return LaunchDescription([
        # 파라미터
        DeclareLaunchArgument(
            'use_sim_time',
            default_value='true',
            description='시뮬레이션 시간 사용 여부'
        ),
        
        # SLAM 런치 포함
        multi_robot_slam_launch,
        
        # 좌표 송수신 노드들
        coord_nodes
    ])
