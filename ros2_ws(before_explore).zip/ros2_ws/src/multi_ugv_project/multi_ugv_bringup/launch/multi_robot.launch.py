#!/usr/bin/env python3

import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, DeclareLaunchArgument, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
import xacro

def generate_launch_description():
    # 패키지 경로
    pkg_bringup = get_package_share_directory('multi_ugv_bringup')
    pkg_description = get_package_share_directory('multi_ugv_description')
    
    # URDF/XACRO 파일 경로
    xacro_file = os.path.join(pkg_description, 'urdf', 'ugv.urdf.xacro')
    
    # 각 로봇에 대한 URDF 생성 - 네임스페이스 제거 또는 수정
    robot1_description = xacro.process_file(
        xacro_file,
        mappings={'robot_name': 'robot1', 'sim_mode': 'true'}
    ).toxml()
    
    robot2_description = xacro.process_file(
        xacro_file,
        mappings={'robot_name': 'robot2', 'sim_mode': 'true'}
    ).toxml()
    
    robot3_description = xacro.process_file(
        xacro_file,
        mappings={'robot_name': 'robot3', 'sim_mode': 'true'}
    ).toxml()
    
    # 로봇 상태 퍼블리셔들 - frame_prefix 제거
    robot1_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot1_state_publisher',
        namespace='robot1',
        parameters=[{
            'robot_description': robot1_description,
            'use_sim_time': True,
            # frame_prefix 제거 - URDF에 이미 'robot1/' 접두사가 포함되어 있음
        }],
        output='screen'
    )
    
    robot2_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot2_state_publisher',
        namespace='robot2',
        parameters=[{
            'robot_description': robot2_description,
            'use_sim_time': True,
            # frame_prefix 제거 - URDF에 이미 'robot2/' 접두사가 포함되어 있음
        }],
        output='screen'
    )
    
    robot3_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot3_state_publisher',
        namespace='robot3',
        parameters=[{
            'robot_description': robot3_description,
            'use_sim_time': True,
            # frame_prefix 제거 - URDF에 이미 'robot3/' 접두사가 포함되어 있음
        }],
        output='screen'
    )
    
    # 로봇 스폰 노드들은 변경 없이 유지
    robot1_spawn = Node(
        package='gazebo_ros', 
        executable='spawn_entity.py',
        arguments=[
            '-entity', 'robot1',
            '-topic', '/robot1/robot_description',
            '-x', '0.0',
            '-y', '1.0',
            '-z', '0.01'
        ],
        output='screen'
    )
    
    robot2_spawn = Node(
        package='gazebo_ros', 
        executable='spawn_entity.py',
        arguments=[
            '-entity', 'robot2',
            '-topic', '/robot2/robot_description',
            '-x', '1.0',
            '-y', '0.0',
            '-z', '0.01'
        ],
        output='screen'
    )
    
    robot3_spawn = Node(
        package='gazebo_ros', 
        executable='spawn_entity.py',
        arguments=[
            '-entity', 'robot3',
            '-topic', '/robot3/robot_description',
            '-x', '-1.0',
            '-y', '-1.0',
            '-z', '0.01'
        ],
        output='screen'
    )
    
    # 타이머로 지연된 로봇 스폰
    robot1_spawn_with_delay = TimerAction(
        period=5.0,
        actions=[robot1_spawn]
    )
    
    robot2_spawn_with_delay = TimerAction(
        period=7.0,
        actions=[robot2_spawn]
    )
    
    robot3_spawn_with_delay = TimerAction(
        period=9.0,
        actions=[robot3_spawn]
    )
    

    
    # LaunchDescription 반환
    return LaunchDescription([
        robot1_state_publisher,
        robot2_state_publisher,
        robot3_state_publisher,
        robot1_spawn_with_delay,
        robot2_spawn_with_delay,
        robot3_spawn_with_delay,

    ])
