#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
import time

class JointStatePublisherNode(Node):
    def __init__(self, robot_name='robot1'):
        super().__init__(f'{robot_name}_joint_state_publisher')
        
        # 로봇 이름 저장
        self.robot_name = robot_name
        
        # 조인트 상태 발행자
        self.joint_state_publisher = self.create_publisher(
            JointState,
            f'/{robot_name}/joint_states',
            10
        )
        
        # 타이머 설정 (50Hz)
        self.timer = self.create_timer(0.02, self.publish_joint_states)
        
        # 조인트 이름 설정
        self.joint_names = [
            f'{robot_name}/front_left_wheel_joint',
            f'{robot_name}/front_right_wheel_joint',
            f'{robot_name}/back_left_wheel_joint',
            f'{robot_name}/back_right_wheel_joint'
        ]
        
        self.get_logger().info(f'{robot_name} 조인트 상태 발행 노드 시작')
    
    def publish_joint_states(self):
        # 조인트 상태 메시지 생성
        joint_state = JointState()
        joint_state.header.stamp = self.get_clock().now().to_msg()
        joint_state.name = self.joint_names
        
        # 기본 위치 (모든 조인트 0 위치)
        joint_state.position = [0.0, 0.0, 0.0, 0.0]
        
        # 발행
        self.joint_state_publisher.publish(joint_state)

def main(args=None):
    rclpy.init(args=args)
    
    # 명령행에서 로봇 이름을 받을 수 있도록 설정
    import sys
    robot_name = 'robot1'  # 기본값
    if len(sys.argv) > 1:
        robot_name = sys.argv[1]
    
    node = JointStatePublisherNode(robot_name)
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
