#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from nav_msgs.msg import OccupancyGrid, Odometry
from geometry_msgs.msg import TransformStamped, Quaternion, Pose
from tf2_ros import TransformBroadcaster
import math

class SlamNode(Node):
    def __init__(self, robot_name='robot1'):
        super().__init__(f'{robot_name}_slam_helper')
        
        # 로봇 이름 저장
        self.robot_name = robot_name
        
        # 초기 위치 설정
        self.initial_positions = {
            'robot1': (0.0, 0.0, 0.0),  # x, y, yaw
            'robot2': (0.0, 0.0, 0.0),
            'robot3': (0.0, 0.0, 0.0)
        }
        
        # 현재 위치 및 방향 저장
        self.current_pose = Pose()
        
        # QoS 설정
        map_qos = rclpy.qos.QoSProfile(
            durability=rclpy.qos.QoSDurabilityPolicy.TRANSIENT_LOCAL,
            reliability=rclpy.qos.QoSReliabilityPolicy.RELIABLE,
            history=rclpy.qos.HistoryPolicy.KEEP_LAST,
            depth=1
        )
        
        # 맵 구독자 추가
        self.map_subscription = self.create_subscription(
            OccupancyGrid,
            f'/{robot_name}/map',
            self.map_callback,
            map_qos
        )
        
        # 오도메트리 구독
        self.odom_subscription = self.create_subscription(
            Odometry,
            f'/{robot_name}/odom',  # 로봇별 오도메트리 토픽
            self.odom_callback,
            10
        )
        
        # TF 브로드캐스터 설정
        self.tf_broadcaster = TransformBroadcaster(self)
        
        # TF 발행 타이머 (50Hz로 증가)
        self.tf_timer = self.create_timer(0.02, self.publish_transforms)
        
        self.get_logger().info(f'{robot_name} SLAM 헬퍼 노드 시작됨')
    
    def map_callback(self, msg):
        """맵 메시지 수신 처리"""
        self.get_logger().info(f'{self.robot_name} 맵 데이터 수신 (크기: {msg.info.width}x{msg.info.height})')
    
    def odom_callback(self, msg):
        # 오도메트리 메시지에서 현재 위치와 방향 저장
        self.current_pose = msg.pose.pose
        
        # odom -> base_footprint TF 발행
        self.publish_odom_to_base_tf(self.current_pose)
    
    def euler_to_quaternion(self, roll, pitch, yaw):
        cy = math.cos(yaw * 0.5)
        sy = math.sin(yaw * 0.5)
        cp = math.cos(pitch * 0.5)
        sp = math.sin(pitch * 0.5)
        cr = math.cos(roll * 0.5)
        sr = math.sin(roll * 0.5)
        
        q = Quaternion()
        q.w = cr * cp * cy + sr * sp * sy
        q.x = sr * cp * cy - cr * sp * sy
        q.y = cr * sp * cy + sr * cp * sy
        q.z = cr * cp * sy - sr * sp * cy
        
        return q
    
    def publish_transforms(self):
        # 필요한 모든 TF 변환 보조 발행
        # 초기 위치를 기반으로 odom -> base_footprint 백업 TF 발행
        # 오도메트리 콜백이 아직 작동하지 않을 경우를 대비
        if self.current_pose.position.x == 0.0 and self.current_pose.position.y == 0.0 and self.current_pose.position.z == 0.0:
            initial_pose = Pose()
            x, y, yaw = self.initial_positions.get(self.robot_name, (0.0, 0.0, 0.0))
            initial_pose.position.x = 0.0  # 오돔 프레임 기준으로는 시작 위치가 0,0
            initial_pose.position.y = 0.0
            initial_pose.position.z = 0.0
            initial_pose.orientation = self.euler_to_quaternion(0.0, 0.0, 0.0)
            self.publish_odom_to_base_tf(initial_pose)
    
    def publish_odom_to_base_tf(self, pose):
        # 오돔 -> 베이스 풋프린트 변환 설정
        t = TransformStamped()
        t.header.stamp = self.get_clock().now().to_msg()
        t.header.frame_id = f"{self.robot_name}/odom"
        t.child_frame_id = f"{self.robot_name}/base_footprint"
        
        # 현재 위치와 방향 설정
        t.transform.translation.x = pose.position.x
        t.transform.translation.y = pose.position.y
        t.transform.translation.z = pose.position.z
        
        t.transform.rotation.x = pose.orientation.x
        t.transform.rotation.y = pose.orientation.y
        t.transform.rotation.z = pose.orientation.z
        t.transform.rotation.w = pose.orientation.w
        
        self.tf_broadcaster.sendTransform(t)

def main(args=None):
    rclpy.init(args=args)
    
    # 명령행에서 로봇 이름을 받음
    import sys
    robot_name = 'robot1'  # 기본값
    if len(sys.argv) > 1:
        robot_name = sys.argv[1]
    
    node = SlamNode(robot_name)
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
