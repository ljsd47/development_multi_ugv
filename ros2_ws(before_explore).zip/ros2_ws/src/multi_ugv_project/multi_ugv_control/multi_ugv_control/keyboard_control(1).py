#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import sys
import tty
import termios
import select
import os
import time

msg = """
메카넘 휠 로봇 키보드 제어
---------------------------
이동 키:
   u    i    o
   j    k    l
   m    ,    .

i/,: 전진/후진
j/l: 좌/우 이동
u/o: 전방 좌/우 대각선 이동
m/.: 후방 좌/우 대각선 이동
q/e: 좌/우 회전
k: 정지
스페이스바: 긴급 정지

CTRL-C: 종료
"""

# 메카넘 휠 움직임 매핑 - (linear.x, linear.y, angular.z)
moveBindings = {
    'i': (1, 0, 0),     # 전진
    'o': (0.707, -0.707, 0),   # 전방 우측 대각선
    'j': (0, 1, 0),     # 좌측 이동
    'l': (0, -1, 0),    # 우측 이동
    'u': (0.707, 0.707, 0),   # 전방 좌측 대각선
    ',': (-1, 0, 0),    # 후진
    '.': (-0.707, -0.707, 0),  # 후방 우측 대각선
    'm': (-0.707, 0.707, 0),  # 후방 좌측 대각선
    'q': (0, 0, 1),     # 좌회전
    'e': (0, 0, -1),    # 우회전
    'k': (0, 0, 0),     # 정지
}

class MecanumKeyboardController(Node):
    def __init__(self):
        super().__init__('mecanum_keyboard_controller')
        
        # 파라미터 선언
        self.declare_parameter('robot_name', 'robot1')
        self.declare_parameter('linear_speed', 0.5)  # 최대 선속도 (m/s)
        self.declare_parameter('angular_speed', 1.0)  # 최대 각속도 (rad/s)
        
        # 파라미터 가져오기
        self.robot_name = self.get_parameter('robot_name').value
        self.linear_speed = self.get_parameter('linear_speed').value
        self.angular_speed = self.get_parameter('angular_speed').value
        
        # 명령 속도 발행자
        self.cmd_vel_publisher = self.create_publisher(
            Twist,
            f'/{self.robot_name}/cmd_vel',
            10
        )
        
        # 현재 설정 표시
        self.print_settings()
    
    def print_settings(self):
        """현재 설정 출력"""
        os.system('clear')
        print(msg)
        print(f"로봇: {self.robot_name}")
        print(f"선속도: {self.linear_speed} m/s, 각속도: {self.angular_speed} rad/s\n")
    
    def publish_cmd_vel(self, linear_x, linear_y, angular_z):
        """명령 속도 발행"""
        twist = Twist()
        twist.linear.x = linear_x * self.linear_speed
        twist.linear.y = linear_y * self.linear_speed
        twist.angular.z = angular_z * self.angular_speed
        
        self.cmd_vel_publisher.publish(twist)
        
        # 상태 출력
        if any([linear_x, linear_y, angular_z]):
            print(f"\r속도: linear.x={twist.linear.x:.2f}, linear.y={twist.linear.y:.2f}, angular.z={twist.angular.z:.2f}", end='', flush=True)
        else:
            print(f"\r정지                                           ", end='', flush=True)

def getKey(settings):
    """키보드 입력 처리 함수"""
    tty.setraw(sys.stdin.fileno())
    rlist, _, _ = select.select([sys.stdin], [], [], 0.1)
    if rlist:
        key = sys.stdin.read(1)
    else:
        key = ''
    termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
    
    return key

def main():
    """메인 함수"""
    # 터미널 설정 저장
    settings = termios.tcgetattr(sys.stdin)
    
    rclpy.init()
    node = MecanumKeyboardController()
    
    try:
        while rclpy.ok():
            key = getKey(settings)
            
            # ESC 또는 CTRL-C로 종료
            if key == '\x1b' or key == '\x03':
                break
                
            # 속도 명령 처리
            if key in moveBindings:
                linear_x, linear_y, angular_z = moveBindings[key]
                node.publish_cmd_vel(linear_x, linear_y, angular_z)
            elif key == ' ':  # 스페이스바 - 긴급 정지
                node.publish_cmd_vel(0, 0, 0)
            
            # ROS 콜백 처리
            rclpy.spin_once(node, timeout_sec=0.01)
            
    except Exception as e:
        print(f"\n오류 발생: {str(e)}")
    
    finally:
        # 정지 명령 전송
        node.publish_cmd_vel(0, 0, 0)
        # 터미널 설정 복원
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
        # 노드 종료
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
