#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import Float32MultiArray
from sensor_msgs.msg import Imu
from nav_msgs.msg import Odometry
import serial
import json
import threading
import time

class ArduinoInterface(Node):
    """
    아두이노 인터페이스 노드
    
    ROS2와 아두이노 간의 통신을 담당:
    1. 메카넘 휠 속도 명령을 아두이노로 전송
    2. 아두이노의 엔코더, IMU 데이터를 ROS2로 전달
    """
    
    def __init__(self):
        super().__init__('arduino_interface')
        
        # 파라미터 선언
        self.declare_parameter('robot_name', 'robot1')
        self.declare_parameter('serial_port', '/dev/ttyACM0')
        self.declare_parameter('serial_baudrate', 115200)
        self.declare_parameter('serial_timeout', 0.1)
        
        # 파라미터 가져오기
        self.robot_name = self.get_parameter('robot_name').value
        self.serial_port = self.get_parameter('serial_port').value
        self.baudrate = self.get_parameter('serial_baudrate').value
        self.timeout = self.get_parameter('serial_timeout').value
        
        # 시리얼 연결 설정
        try:
            self.serial = serial.Serial(
                port=self.serial_port,
                baudrate=self.baudrate,
                timeout=self.timeout
            )
            self.get_logger().info(f'시리얼 포트 연결 성공: {self.serial_port}')
        except serial.SerialException as e:
            self.get_logger().error(f'시리얼 포트 연결 실패: {str(e)}')
            self.serial = None
        
        # 구독자: 메카넘 휠 속도 명령 수신
        self.wheel_vel_sub = self.create_subscription(
            Float32MultiArray,
            f'/{self.robot_name}/wheel_velocities',
            self.wheel_vel_callback,
            10
        )
        
        # 발행자: 아두이노에서 받은 센서 데이터 발행
        self.imu_publisher = self.create_publisher(
            Imu,
            f'/{self.robot_name}/imu/data',
            10
        )
        
        self.odom_publisher = self.create_publisher(
            Odometry,
            f'/{self.robot_name}/odom',
            10
        )
        
        # 시리얼 통신 스레드 시작
        if self.serial:
            self.running = True
            self.serial_thread = threading.Thread(target=self.serial_read_thread)
            self.serial_thread.daemon = True
            self.serial_thread.start()
            self.get_logger().info('시리얼 읽기 스레드 시작됨')
        
        self.get_logger().info(f'{self.robot_name} 아두이노 인터페이스 시작됨')
    
    def wheel_vel_callback(self, msg):
        """휠 속도 명령을 아두이노로 전송"""
        if not self.serial:
            return
            
        # 아두이노로 전송할 데이터 준비
        command = {
            'cmd': 'wheel_vel',
            'fl': msg.data[0],  # 좌측 전방
            'fr': msg.data[1],  # 우측 전방
            'bl': msg.data[2],  # 좌측 후방
            'br': msg.data[3]   # 우측 후방
        }
        
        # JSON 형식으로 변환 후 전송
        try:
            json_command = json.dumps(command) + '\n'
            self.serial.write(json_command.encode())
        except Exception as e:
            self.get_logger().error(f'명령 전송 오류: {str(e)}')
    
    def serial_read_thread(self):
        """아두이노에서 데이터를 읽는 스레드"""
        while self.running:
            try:
                if self.serial.in_waiting > 0:
                    # 한 줄 읽기
                    line = self.serial.readline().decode('utf-8').strip()
                    
                    # 유효한 JSON 데이터인지 확인
                    if line.startswith('{') and line.endswith('}'):
                        try:
                            data = json.loads(line)
                            self.process_arduino_data(data)
                        except json.JSONDecodeError:
                            self.get_logger().warning(f'JSON 파싱 오류: {line}')
                    else:
                        # 단순 로그 메시지 출력
                        if line:
                            self.get_logger().debug(f'아두이노: {line}')
            except Exception as e:
                self.get_logger().error(f'시리얼 읽기 오류: {str(e)}')
                time.sleep(1.0)  # 오류 발생 시 잠시 대기
    
    def process_arduino_data(self, data):
        """아두이노에서 받은 데이터 처리"""
        # 데이터 타입 확인
        if 'type' not in data:
            return
            
        if data['type'] == 'imu':
            # IMU 데이터 처리
            imu_msg = Imu()
            imu_msg.header.stamp = self.get_clock().now().to_msg()
            imu_msg.header.frame_id = f'{self.robot_name}/imu_link'
            
            # 데이터 검증
            if all(k in data for k in ['ax', 'ay', 'az', 'gx', 'gy', 'gz', 'qw', 'qx', 'qy', 'qz']):
                # 가속도계 데이터 (m/s^2)
                imu_msg.linear_acceleration.x = data['ax']
                imu_msg.linear_acceleration.y = data['ay']
                imu_msg.linear_acceleration.z = data['az']
                
                # 자이로스코프 데이터 (rad/s)
                imu_msg.angular_velocity.x = data['gx']
                imu_msg.angular_velocity.y = data['gy']
                imu_msg.angular_velocity.z = data['gz']
                
                # 쿼터니언 방향
                imu_msg.orientation.w = data['qw']
                imu_msg.orientation.x = data['qx']
                imu_msg.orientation.y = data['qy']
                imu_msg.orientation.z = data['qz']
                
                # 공분산 설정 (고정값 사용)
                for i in range(9):
                    imu_msg.orientation_covariance[i] = 0.01
                    imu_msg.angular_velocity_covariance[i] = 0.01
                    imu_msg.linear_acceleration_covariance[i] = 0.01
                
                # IMU 데이터 발행
                self.imu_publisher.publish(imu_msg)
                
        elif data['type'] == 'odom':
            # 오도메트리 데이터 처리
            odom_msg = Odometry()
            odom_msg.header.stamp = self.get_clock().now().to_msg()
            odom_msg.header.frame_id = f'{self.robot_name}/odom'
            odom_msg.child_frame_id = f'{self.robot_name}/base_link'
            
            # 데이터 검증
            if all(k in data for k in ['x', 'y', 'theta', 'vx', 'vy', 'vtheta']):
                # 위치
                odom_msg.pose.pose.position.x = data['x']
                odom_msg.pose.pose.position.y = data['y']
                odom_msg.pose.pose.position.z = 0.0
                
                # 방향 (쿼터니언)
                theta = data['theta']
                odom_msg.pose.pose.orientation.w = math.cos(theta/2)
                odom_msg.pose.pose.orientation.x = 0.0
                odom_msg.pose.pose.orientation.y = 0.0
                odom_msg.pose.pose.orientation.z = math.sin(theta/2)
                
                # 속도
                odom_msg.twist.twist.linear.x = data['vx']
                odom_msg.twist.twist.linear.y = data['vy']
                odom_msg.twist.twist.angular.z = data['vtheta']
                
                # 공분산 설정 (고정값 사용)
                for i in range(36):
                    odom_msg.pose.covariance[i] = 0.0
                    odom_msg.twist.covariance[i] = 0.0
                
                # 주요 공분산 설정
                odom_msg.pose.covariance[0] = 0.01   # x 위치
                odom_msg.pose.covariance[7] = 0.01   # y 위치
                odom_msg.pose.covariance[35] = 0.01  # 회전
                
                odom_msg.twist.covariance[0] = 0.01   # x 속도
                odom_msg.twist.covariance[7] =.01    # y 속도
                odom_msg.twist.covariance[35] = 0.01  # 회전 속도
                
                # 오도메트리 데이터 발행
                self.odom_publisher.publish(odom_msg)
    
    def destroy_node(self):
        """노드 종료 시 정리 작업"""
        self.running = False
        if self.serial:
            # 정지 명령 전송
            stop_command = json.dumps({'cmd': 'wheel_vel', 'fl': 0.0, 'fr': 0.0, 'bl': 0.0, 'br': 0.0}) + '\n'
            try:
                self.serial.write(stop_command.encode())
                time.sleep(0.1)  # 명령이 전송될 시간 확보
            except:
                pass
            
            # 시리얼 포트 닫기
            self.serial.close()
            
        super().destroy_node()

def main(args=None):
    rclpy.init(args=args)
    node = ArduinoInterface()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
