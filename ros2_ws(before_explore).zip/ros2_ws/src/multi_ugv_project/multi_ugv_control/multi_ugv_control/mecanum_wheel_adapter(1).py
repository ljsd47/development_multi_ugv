#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import Float32MultiArray
import numpy as np
import math

class MecanumWheelAdapter(Node):
    """
    메카넘 휠 어댑터 노드
    
    키보드 제어 명령을 받아 메카넘 휠 역기구학을 적용하여 각 휠의 속도 계산
    """
    
    def __init__(self):
        super().__init__('mecanum_wheel_adapter')
        
        # 파라미터 선언
        self.declare_parameter('robot_name', 'robot1')
        self.declare_parameter('wheel_radius', 0.04)  # 휠 반경 (m)
        self.declare_parameter('wheel_separation_x', 0.158)  # 휠 x방향 간격 (m)
        self.declare_parameter('wheel_separation_y', 0.158)  # 휠 y방향 간격 (m)
        self.declare_parameter('max_linear_velocity', 1.0)  # 최대 선속도 (m/s)
        self.declare_parameter('max_angular_velocity', 2.0)  # 최대 각속도 (rad/s)
        
    # 파라미터 가져오기 (에러 처리 추가)
        try:
            self.robot_name = self.get_parameter('robot_name').value
            self.wheel_radius = self.get_parameter('wheel_radius').value
            self.wheel_separation_x = self.get_parameter('wheel_separation_x').value
            self.wheel_separation_y = self.get_parameter('wheel_separation_y').value
            self.max_linear_velocity = self.get_parameter('max_linear_velocity').value
            self.max_angular_velocity = self.get_parameter('max_angular_velocity').value
            
            # 역기구학 계산을 위한 로봇 크기 파라미터
            self.L = (self.wheel_separation_x + self.wheel_separation_y) / 2.0
        
            # 구독자: 키보드 제어 명령 수신
            self.cmd_vel_sub = self.create_subscription(
                Twist,
                f'/{self.robot_name}/cmd_vel',
                self.cmd_vel_callback,
                10
            )
        
            # 디버그 발행자
            self.debug_vel_pub = self.create_publisher(
                Twist,
                f'/{self.robot_name}/debug_vel',
                10
            )
            
            self.get_logger().info(f'{self.robot_name} 메카넘 휠 어댑터 시작됨: wheel_radius={self.wheel_radius}, separation=({self.wheel_separation_x}, {self.wheel_separation_y})')
    
        except Exception as e:
            self.get_logger().error(f'파라미터 초기화 오류: {str(e)}')
            # 파라미터 확인 로깅
            for param_name in ['robot_name', 'wheel_radius', 'wheel_separation_x', 'wheel_separation_y']:
                try:
                    value = self.get_parameter(param_name).value
                    self.get_logger().info(f'파라미터 {param_name} = {value}')
                except:
                    self.get_logger().error(f'파라미터 {param_name} 읽기 실패')
            raise
        # 역기구학 계산을 위한 로봇 크기 파라미터
        self.L = self.wheel_separation_x / 2.0 + self.wheel_separation_y / 2.0
        
        # 구독자: 키보드 제어 명령 수신
        self.cmd_vel_sub = self.create_subscription(
            Twist,
            f'/{self.robot_name}/cmd_vel',
            self.cmd_vel_callback,
            10
        )
        
        # 발행자: 각 휠 속도 명령 (아두이노로 전송)
        self.wheel_vel_pub = self.create_publisher(
            Float32MultiArray,
            f'/{self.robot_name}/wheel_velocities',
            10
        )
        
        # 디버그 발행자
        self.debug_vel_pub = self.create_publisher(
            Twist,
            f'/{self.robot_name}/debug_vel',
            10
        )
        
        self.get_logger().info(f'{self.robot_name} 메카넘 휠 어댑터 시작됨')
    
    def cmd_vel_callback(self, msg):
        """
        cmd_vel 메시지를 받아 메카넘 휠 속도로 변환
        """
        # 명령 속도 제한
        linear_x = self.clamp(msg.linear.x, -self.max_linear_velocity, self.max_linear_velocity)
        linear_y = self.clamp(msg.linear.y, -self.max_linear_velocity, self.max_linear_velocity)
        angular_z = self.clamp(msg.angular.z, -self.max_angular_velocity, self.max_angular_velocity)
        
        # 속도 보정 (사용자 경험 향상을 위한 선형/각속도 균형 조정)
        if abs(angular_z) > 0.05 and (abs(linear_x) > 0.05 or abs(linear_y) > 0.05):
            # 회전하면서 이동할 때 각속도 감소 (더 자연스러운 이동을 위해)
            angular_z *= 0.7
        
        # 메카넘 휠 역기구학 적용
        # 순서: 좌측 전방(FL), 우측 전방(FR), 좌측 후방(BL), 우측 후방(BR)
        wheel_fl = linear_x - linear_y - self.L * angular_z
        wheel_fr = linear_x + linear_y + self.L * angular_z
        wheel_bl = linear_x + linear_y - self.L * angular_z
        wheel_br = linear_x - linear_y + self.L * angular_z
        
        # 최대 휠 속도 계산 및 정규화
        max_wheel_speed = max(abs(wheel_fl), abs(wheel_fr), abs(wheel_bl), abs(wheel_br))
        if max_wheel_speed > 1.0:
            # 최대 속도를 초과하면 모든 휠 속도 비례적으로 축소
            wheel_fl /= max_wheel_speed
            wheel_fr /= max_wheel_speed
            wheel_bl /= max_wheel_speed
            wheel_br /= max_wheel_speed
        
        # 휠 속도 메시지 생성 (아두이노로 전송)
        wheel_msg = Float32MultiArray()
        wheel_msg.data = [float(wheel_fl), float(wheel_fr), float(wheel_bl), float(wheel_br)]
        self.wheel_vel_pub.publish(wheel_msg)
        
        # 디버그 정보 발행
        debug_msg = Twist()
        debug_msg.linear.x = linear_x
        debug_msg.linear.y = linear_y
        debug_msg.angular.z = angular_z
        self.debug_vel_pub.publish(debug_msg)
        
        # 휠 속도 로깅 (디버깅용)
        if max(abs(linear_x), abs(linear_y), abs(angular_z)) > 0.05:
            self.get_logger().debug(
                f'cmd_vel: [{linear_x:.2f}, {linear_y:.2f}, {angular_z:.2f}] -> '
                f'wheels: [{wheel_fl:.2f}, {wheel_fr:.2f}, {wheel_bl:.2f}, {wheel_br:.2f}]'
            )
    
    def clamp(self, value, min_value, max_value):
        """값을 최소/최대 범위 내로 제한"""
        return max(min(value, max_value), min_value)

def main(args=None):
    rclpy.init(args=args)
    node = MecanumWheelAdapter()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
