#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import TransformStamped
from tf2_ros import StaticTransformBroadcaster, TransformBroadcaster
import math

class TFManagerNode(Node):
    def __init__(self):
        super().__init__('tf_manager')
        
        # 로봇 이름 목록
        self.robot_names = ['robot1', 'robot2', 'robot3']
        
        # 로봇 초기 위치 (x, y, yaw)
        self.robot_initial_poses = {
            'robot1': (0.0, 1.0, 0.0),  # x, y, yaw
            'robot2': (1.0, 0.0, 0.0),
            'robot3': (-1.0, -1.0, 0.0)
        }
        
        # 정적 TF 브로드캐스터
        self.static_broadcaster = StaticTransformBroadcaster(self)
        
        # 동적 TF 브로드캐스터
        self.tf_broadcaster = TransformBroadcaster(self)
        
        # world -> map, map -> robot#/map 정적 변환 설정
        self.setup_static_transforms()
        
        # map -> odom 변환 발행 타이머 (중요! 높은 주파수로 설정)
        self.tf_timer = self.create_timer(0.01, self.publish_map_to_odom_transforms)
        
        self.get_logger().info('TF 매니저 노드 시작됨')
    
    def euler_to_quaternion(self, roll, pitch, yaw):
        """오일러 각도를 쿼터니언으로 변환"""
        cy = math.cos(yaw * 0.5)
        sy = math.sin(yaw * 0.5)
        cp = math.cos(pitch * 0.5)
        sp = math.sin(pitch * 0.5)
        cr = math.cos(roll * 0.5)
        sr = math.sin(roll * 0.5)
        
        qw = cr * cp * cy + sr * sp * sy
        qx = sr * cp * cy - cr * sp * sy
        qy = cr * sp * cy + sr * cp * sy
        qz = cr * cp * sy - sr * sp * cy
        
        return qw, qx, qy, qz
    
    def setup_static_transforms(self):
        """정적 TF 설정 (world -> map -> robot#/map)"""
        # world -> map 변환
        world_to_map = TransformStamped()
        world_to_map.header.stamp = self.get_clock().now().to_msg()
        world_to_map.header.frame_id = "world"
        world_to_map.child_frame_id = "map"
        world_to_map.transform.rotation.w = 1.0
        
        self.static_broadcaster.sendTransform(world_to_map)
        self.get_logger().info('정적 TF 설정: world -> map')
        
        # map -> robot#/map 변환
        for robot_name in self.robot_names:
            map_to_robot_map = TransformStamped()
            map_to_robot_map.header.stamp = self.get_clock().now().to_msg()
            map_to_robot_map.header.frame_id = "map"
            map_to_robot_map.child_frame_id = f"{robot_name}/map"
            map_to_robot_map.transform.rotation.w = 1.0
            
            self.static_broadcaster.sendTransform(map_to_robot_map)
            self.get_logger().info(f'정적 TF 설정: map -> {robot_name}/map')
    
    def publish_map_to_odom_transforms(self):
        """각 로봇의 map -> odom 변환 발행 (중요!)"""
        current_time = self.get_clock().now().to_msg()
        
        for robot_name in self.robot_names:
            # 중요: robot#/map -> robot#/odom 변환 생성
            map_to_odom = TransformStamped()
            map_to_odom.header.stamp = current_time
            map_to_odom.header.frame_id = f"{robot_name}/map"
            map_to_odom.child_frame_id = f"{robot_name}/odom"
            
            # 초기 위치 적용 (필요시)
            x, y, yaw = self.robot_initial_poses.get(robot_name, (0.0, 0.0, 0.0))
            
            # 변환 설정
            map_to_odom.transform.translation.x = 0.0
            map_to_odom.transform.translation.y = 0.0
            map_to_odom.transform.translation.z = 0.0
            
            # 회전 설정
            qw, qx, qy, qz = self.euler_to_quaternion(0.0, 0.0, 0.0)
            map_to_odom.transform.rotation.w = qw
            map_to_odom.transform.rotation.x = qx
            map_to_odom.transform.rotation.y = qy
            map_to_odom.transform.rotation.z = qz
            
            # 변환 발행
            self.tf_broadcaster.sendTransform(map_to_odom)

def main(args=None):
    rclpy.init(args=args)
    node = TFManagerNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
