#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from nav_msgs.msg import OccupancyGrid
from geometry_msgs.msg import TransformStamped
from tf2_ros import StaticTransformBroadcaster
import numpy as np
import math

class MapConverter(Node):
    def __init__(self):
        super().__init__('map_converter')
        
        # 맵 QoS 설정 - 트랜지언트 로컬로 변경
        map_qos = rclpy.qos.QoSProfile(
            durability=rclpy.qos.QoSDurabilityPolicy.TRANSIENT_LOCAL,
            reliability=rclpy.qos.QoSReliabilityPolicy.RELIABLE,
            history=rclpy.qos.HistoryPolicy.KEEP_LAST,
            depth=1
        )
        
        # 전역 맵 발행자
        self.global_map_publisher = self.create_publisher(
            OccupancyGrid, 
            '/map',  # 전역 맵 토픽
            map_qos
        )
        
        # 로봇별 맵 발행자
        self.robot_map_publishers = {}
        self.robot_names = ['robot1', 'robot2', 'robot3']
        
        for robot_name in self.robot_names:
            self.robot_map_publishers[robot_name] = self.create_publisher(
                OccupancyGrid,
                f'/{robot_name}/map',  # 로봇별 맵 토픽
                map_qos
            )
        
        # 로봇별 맵 구독자 설정
        self.robot_maps = {}
        self.setup_robot_map_subscribers(map_qos)
        
        # 정적 TF 브로드캐스터
        self.static_broadcaster = StaticTransformBroadcaster(self)
        
        # 타이머 설정 - 1초마다 맵 발행
        self.map_timer = self.create_timer(1.0, self.publish_map)
        
        self.get_logger().info('맵 변환 노드 시작됨')

    def setup_robot_map_subscribers(self, map_qos):
        """각 로봇별 맵 구독자 설정"""
        for robot_name in self.robot_names:
            # 맵 데이터 초기화
            self.robot_maps[robot_name] = None
            
            # 맵 구독자 생성
            self.create_subscription(
                OccupancyGrid,
                f'/{robot_name}/map',
                lambda msg, name=robot_name: self.robot_map_callback(msg, name),
                map_qos
            )
            
            self.get_logger().info(f'{robot_name} 맵 구독자 생성됨')
    
    def robot_map_callback(self, msg, robot_name):
        """각 로봇의 맵 메시지 수신 처리"""
        if msg:
            self.robot_maps[robot_name] = msg
            self.get_logger().info(f'{robot_name} 맵 데이터 수신 (크기: {msg.info.width}x{msg.info.height})')

    def create_map(self):
        # 맵 메시지 생성
        map_msg = OccupancyGrid()
        map_msg.header.stamp = self.get_clock().now().to_msg()
        map_msg.header.frame_id = 'map'  # 맵 프레임 설정
        
        # 맵 메타데이터 설정
        map_msg.info.resolution = 0.05  # 5cm 해상도
        map_msg.info.width = 400  # 20m
        map_msg.info.height = 400 # 20m
        map_msg.info.origin.position.x = -10.0
        map_msg.info.origin.position.y = -10.0
        map_msg.info.origin.position.z = 0.0
        map_msg.info.origin.orientation.w = 1.0
        
        # 맵 데이터 초기화 (-1 = 미지 영역)
        map_data = np.full(map_msg.info.width * map_msg.info.height, -1, dtype=np.int8)
        
        # 중앙 영역을 자유 공간으로 설정 (0 = 자유 공간)
        center_area = 200  # 10m x 10m
        center_x = map_msg.info.width // 2
        center_y = map_msg.info.height // 2
        
        for y in range(center_y - center_area//2, center_y + center_area//2):
            for x in range(center_x - center_area//2, center_x + center_area//2):
                if 0 <= y < map_msg.info.height and 0 <= x < map_msg.info.width:
                    map_data[y * map_msg.info.width + x] = 0
        
        # 미로 벽 정보: (x, y, z, yaw, size_x, size_y, size_z)
        walls = [
            (3, 0, 0.5, 0, 0.1, 4.0, 1.0),        # wall1
            (-2, 4, 0.5, 0, 0.1, 4.0, 1.0),       # wall3
            (-2, -0.5, 0.5, 0, 0.1, 3.0, 1.0),    # wall4
            (-0.5, -2, 0.5, 1.5708, 0.1, 3.0, 1.0), # wall5
            (1, -4, 0.5, 0, 0.1, 4.0, 1.0),       # wall6
            (2, -4.5, 0.5, 0, 0.1, 3.0, 1.0),     # wall7
            (3.5, -3, 0.5, 1.5708, 0.1, 3.0, 1.0), # wall8
            (6, 1, 0.5, 1.5708, 0.1, 4.0, 1.0),   # wall9
            (4, 3, 0.5, 0, 0.1, 4.0, 1.0),        # wall10
            (8.5, -2, 0.5, 1.5708, 0.1, 3.0, 1.0), # wall11            
            (5, 8.5, 0.5, 0, 0.1, 3.0, 1.0),      # wall12           
            (7, 4, 0.5, 1.5708, 0.1, 4.0, 1.0),   # wall13
            (8.5, -7.5, 0.5, 0, 0.1, 5.0, 1.0),   # wall14
            (-7, 3, 0.5, 1.5708, 0.1, 3.0, 1.0),  # wall15
            (0, -10, 0.5, 1.5708, 0.1, 20.0, 1.0), # wall16
            (0, 10, 0.5, 1.5708, 0.1, 20.0, 1.0), # wall17
            (-10, 0, 0.5, 0, 0.1, 20.0, 1.0),     # wall18
            (10, 0, 0.5, 0, 0.1, 20.0, 1.0),      # wall19
        ]
        
        # 각 벽을 맵에 그리기
        for wall in walls:
            x, y, z, yaw, size_x, size_y, size_z = wall
            self.draw_wall(map_data, map_msg.info, x, y, yaw, size_x, size_y)
        
        map_msg.data = map_data.tolist()
        return map_msg

    def draw_wall(self, map_data, map_info, x, y, yaw, size_x, size_y):
        """벽을 맵에 그리는 함수"""
        # 월드 좌표를 맵 셀 인덱스로 변환
        x_cell = int((x - map_info.origin.position.x) / map_info.resolution)
        y_cell = int((y - map_info.origin.position.y) / map_info.resolution)
        
        # 벽의 두께와 길이를 셀 단위로 변환
        wall_thickness = max(int(size_x / map_info.resolution), 1)
        wall_length = max(int(size_y / map_info.resolution), 1)
        
        # 회전 변환을 위한 삼각함수 값 계산
        cos_yaw = math.cos(yaw)
        sin_yaw = math.sin(yaw)
        
        # 벽의 각 셀을 맵에 그리기
        for dy in range(-wall_length//2, wall_length//2 + 1):
            for dx in range(-wall_thickness//2, wall_thickness//2 + 1):
                # 회전 변환 적용
                rotated_x = int(dx * cos_yaw - dy * sin_yaw)
                rotated_y = int(dx * sin_yaw + dy * cos_yaw)
                
                # 최종 셀 좌표 계산
                cell_x = x_cell + rotated_x
                cell_y = y_cell + rotated_y
                
                # 맵 경계 확인 후 점유 상태 설정 (100 = 점유)
                if 0 <= cell_x < map_info.width and 0 <= cell_y < map_info.height:
                    map_data[cell_y * map_info.width + cell_x] = 100

    def combine_robot_maps(self):
        """로봇들의 맵 데이터를 결합하여 하나의 통합 맵 생성"""
        # 모든 로봇의 맵을 확인, 유효한 데이터가 있으면 그것을 반환
        for robot_name, map_data in self.robot_maps.items():
            if map_data is not None:
                # 로봇의 맵을 그대로 복사
                combined_map = OccupancyGrid()
                combined_map.header.stamp = self.get_clock().now().to_msg()
                combined_map.header.frame_id = 'map'
                combined_map.info = map_data.info
                combined_map.data = map_data.data
                
                self.get_logger().info(f'{robot_name}의 맵 데이터를 사용하여 전역 맵 생성')
                return combined_map
        
        # 유효한 로봇 맵이 없으면 기본 맵 생성
        self.get_logger().info('유효한 로봇 맵 없음, 기본 맵 생성')
        return self.create_map()

    def publish_map(self):
        """맵을 생성하고 발행하는 함수"""
        # 기본 맵 생성
        global_map = self.create_map()
        
        # 글로벌 맵 발행
        self.global_map_publisher.publish(global_map)
        
        # 각 로봇별 맵도 발행
        for robot_name, publisher in self.robot_map_publishers.items():
            robot_map = OccupancyGrid()
            robot_map.header.stamp = self.get_clock().now().to_msg()
            robot_map.header.frame_id = f"{robot_name}/map"
            robot_map.info = global_map.info
            robot_map.data = global_map.data
            publisher.publish(robot_map)
            
        self.get_logger().debug('맵 발행됨')

def main(args=None):
    rclpy.init(args=args)
    node = MapConverter()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
