#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped, Twist
from nav_msgs.msg import Odometry
from std_msgs.msg import Empty
import math
import numpy as np
import time

class CoordTransmissionNode(Node):
    def __init__(self, robot_name='robot1'):
        super().__init__(f'{robot_name}_coord_transmission')
        
        # 로봇 이름 저장
        self.robot_name = robot_name
        
        # Nav2 목표점 발행자
        self.goal_publisher = self.create_publisher(
            PoseStamped,
            f'/{robot_name}/goal_pose',
            10
        )
        
        # 명령 속도 구독자
        self.cmd_vel_subscription = self.create_subscription(
            Twist,
            f'/{robot_name}/cmd_vel',
            self.cmd_vel_callback,
            10
        )
        
        # 로봇 위치 구독자
        self.odom_subscription = self.create_subscription(
            Odometry,
            f'/{robot_name}/odom',
            self.odom_callback,
            10
        )
        
        # Nav2 취소 발행자
        self.cancel_publisher = self.create_publisher(
            Empty,
            f'/{robot_name}/cancel_goal',
            10
        )
        
        # 현재 로봇 위치 저장
        self.current_pose = PoseStamped()
        self.current_pose.header.frame_id = f"{robot_name}/map"
        
        # 수동 모드인지 자율주행 모드인지 저장
        self.manual_mode = True
        
        # 타이머 설정
        self.timer = self.create_timer(0.1, self.transmit_coords)
        
        self.get_logger().info(f'{robot_name} 좌표 송수신 노드 시작됨')
    
    def cmd_vel_callback(self, msg):
        # cmd_vel 메시지가 들어오면 수동 모드로 변경
        if abs(msg.linear.x) > 0.001 or abs(msg.linear.y) > 0.001 or abs(msg.angular.z) > 0.001:
            if not self.manual_mode:
                self.manual_mode = True
                self.cancel_current_goal()
                self.get_logger().info('수동 모드로 전환')
    
    def odom_callback(self, msg):
        # 오도메트리 메시지에서 현재 위치 업데이트
        pose = msg.pose.pose
        
        # 맵 프레임에 맞게 변환
        self.current_pose.header.stamp = self.get_clock().now().to_msg()
        self.current_pose.pose = pose
    
    def cancel_current_goal(self):
        # 현재 목표 취소 메시지 발행
        cancel_msg = Empty()
        self.cancel_publisher.publish(cancel_msg)
        self.get_logger().info('네비게이션 목표 취소됨')
    
    def set_navigation_goal(self, x, y, theta=0.0):
        # Nav2 목표점 설정
        goal_msg = PoseStamped()
        goal_msg.header.stamp = self.get_clock().now().to_msg()
        goal_msg.header.frame_id = f"{self.robot_name}/map"
        
        goal_msg.pose.position.x = x
        goal_msg.pose.position.y = y
        goal_msg.pose.position.z = 0.0
        
        # 오일러 각도를 쿼터니언으로 변환
        cy = math.cos(theta * 0.5)
        sy = math.sin(theta * 0.5)
        goal_msg.pose.orientation.x = 0.0
        goal_msg.pose.orientation.y = 0.0
        goal_msg.pose.orientation.z = sy
        goal_msg.pose.orientation.w = cy
        
        self.goal_publisher.publish(goal_msg)
        self.manual_mode = False
        self.get_logger().info(f'네비게이션 목표 설정: x={x:.2f}, y={y:.2f}, theta={theta:.2f}')
    
    def transmit_coords(self):
        # 좌표 송수신 처리 (현재는 더미 구현)
        pass

def main(args=None):
    rclpy.init(args=args)
    
    # 명령행에서 로봇 이름을 받을 수 있도록 설정
    import sys
    robot_name = 'robot1'  # 기본값
    if len(sys.argv) > 1:
        robot_name = sys.argv[1]
    
    node = CoordTransmissionNode(robot_name)
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
