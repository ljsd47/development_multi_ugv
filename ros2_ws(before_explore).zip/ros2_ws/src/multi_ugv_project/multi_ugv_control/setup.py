from setuptools import setup
import os
from glob import glob

package_name = 'multi_ugv_control'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        # 필요한 경우 추가 데이터 파일을 여기에 추가
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='koreatech1',
    maintainer_email='your_email@example.com',
    description='Control package for multiple UGV robots',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'mecanum_adapter=multi_ugv_control.mecanum_wheel_adapter:main',
            'keyboard_control=multi_ugv_control.keyboard_control:main',
            'slam_node=multi_ugv_control.slam_node:main',
            'joint_state_publisher=multi_ugv_control.joint_state_publisher_node:main',
            'map_converter=multi_ugv_control.map_converter_node:main',
            'coord_transmission=multi_ugv_control.coord_transmission_node:main',
            'arduino_interface=multi_ugv_control.arduino_interface:main',
            'tf_manager=multi_ugv_control.tf_manager:main',  # 새로운 노드 추가
        ],
    },
)
